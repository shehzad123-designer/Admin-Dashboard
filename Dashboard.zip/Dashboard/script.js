// $(document).ready(function () {
//   $('#myModal').modal({ backdrop: 'static', keyboard: false });
//   // Show the popup form when the button is clicked

//   // Close the popup form when the close button is clicked
//   $('#closeBtn').click(function () {
//     $('#myModal').modal('hide');
//   });
// });




var xValues = ["India", "US", "UAE", "Germany", "Argentina"];
var yValues = [55, 49, 44, 24, 15];
var barColors = [
  "#2962FF",
  "#FB8C01",
  "#1e7145",
  "#6DCB7C",
  "#F23045"
];

new Chart("myChart", {
  type: "pie",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Product Sales in 2023"
    }
  }
});

var xValues = ["Tshirts", "Jeans", "Shoes", "Electronic", "Household"];
var yValues = [55, 49, 44, 24, 15];
var barColors = [
  "#FF9900",
  "#E701FB",
  "#FF1010",
  "#5301FF",
  "#F23045"
];

new Chart("productChart", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues,

    }],
    hoverOffset: 4
  },
  options: {
    title: {
      display: true,
      text: "Product Sales in 2023"
    }
  }
});



function deleteRow(button) {
  var row = button.closest('tr');
  row.remove();
}
// // Function to add task to the list
// function addTaskToList(task, date) {
//   var listItem = $('<li class="list-group-item">' + task + '<button class="btn btn-danger btn-sm float-right delete-task">Delete</button></li>');
//   listItem.data('date', date);
//   $('#taskList').append(listItem);

//   // Delete button click event
//   $('.delete-task').click(function () {
//     $(this).parent().remove();
//   });
// };



//-----------------(       categoryproduct )----------------------------//


$(document).ready(function () {
  let categoryCounts = {
      category1: 0,
      category2: 0,
      category3: 0,
      category4: 0,
  };


  let productData = localStorage.getItem("productData");
  if (productData) {
      productData = JSON.parse(productData);
      productData.forEach(function (product) {
          const newRow = `<tr data-category="${product.category}">
                              <td>${product.productName}</td>
                              <td>${product.category}</td>
                              <td>${product.price}</td>
                              <td>${product.quantity}</td>
                              <td>
                                  <button class="btn btn-danger btn-sm delete-product">Delete</button>
                                  <button class="btn blue btn-sm edit-product">Edit</button>
                              </td>
                          </tr>`;
          $('#productTableBody').append(newRow);
          categoryCounts[product.category]++;
          $(`#${product.category}Count`).text(`${categoryCounts[product.category]} Products`);
      });
  } else {
      productData = [];
  }

  // Function to save product data to local storage
  function saveProductData() {
      localStorage.setItem("productData", JSON.stringify(productData));
  }

  $('#productForm').submit(function (event) {
      event.preventDefault();
      const productName = $('#productName').val();
      const category = $('#categorySelect').val();
      const price = $('#productprice').val();
      const quantity = $('#productquantity').val();

      // Determine if we are adding or editing a product
      const editing = $(this).data('editing');
      if (editing) {
          // Editing existing product
          const index = $(this).data('index');
          const product = productData[index];
          const oldCategory = product.category; // Store the old category

          // Update product details
          product.productName = productName;
          product.category = category;
          product.price = price;
          product.quantity = quantity;

          // Update category counts if category has changed
          if (oldCategory !== category) {
              categoryCounts[oldCategory]--; // Decrement old category count
              categoryCounts[category]++; // Increment new category count

              // Update category count display
              $(`#${oldCategory}Count`).text(`${categoryCounts[oldCategory]} Products`);
              $(`#${category}Count`).text(`${categoryCounts[category]} Products`);
          }

          // Update the table with edited data
          const editedRow = `<tr data-category="${category}">
                                <td>${productName}</td>
                                <td>${category}</td>
                                <td>${price}</td>
                                <td>${quantity}</td>
                                <td>
                                    <button class="btn btn-danger btn-sm delete-product">Delete</button>
                                    <button class="btn blue btn-sm edit-product">Edit</button>
                                </td>
                            </tr>`;
          $('#productTableBody tr:eq(' + index + ')').replaceWith(editedRow);

          $('#addProductModal').modal('hide'); 
          alert("Product edited successfully.");
      } else {
        
          const newRow = `<tr data-category="${category}">
                            <td>${productName}</td>
                            <td>${category}</td>
                            <td>${price}</td>
                            <td>${quantity}</td>
                            <td>
                                <button class="btn btn-danger btn-sm delete-product">Delete</button>
                                <button class="btn blue btn-sm edit-product">Edit</button>
                            </td>
                        </tr>`;
          $('#productTableBody').append(newRow);
          categoryCounts[category]++;
          $(`#${category}Count`).text(`${categoryCounts[category]} Products`);

          // Add product data to the productData array by id names

          productData.push({
              productName: productName,
              category: category,
              price: price,
              quantity: quantity
          });

          alert("Product added successfully.", function(){
              $('#addProductModal').modal('hide'); 
          });
      }

      // Save updated product data to local storage of added data
      saveProductData();

      // Reset form fields
      $('#productForm')[0].reset();
  });

  $('#productTableBody').on('click', '.delete-product', function () {
      const category = $(this).closest('tr').data('category');
      $(this).closest('tr').remove();
      categoryCounts[category]--;
      $(`#${category}Count`).text(`${categoryCounts[category]} Products`);

      // Remove the deleted product from the productData array
      const index = $(this).closest('tr').index();
      productData.splice(index, 1);

      // Save updated product data to local storage
      saveProductData();
  });

  // Event listener for edit product
  $('#productTableBody').on('click', '.edit-product', function () {
      const index = $(this).closest('tr').index();
      const product = productData[index];

      // Populate the form fields with existing data for editing
      $('#productName').val(product.productName);
      $('#categorySelect').val(product.category);
      $('#productprice').val(product.price);
      $('#productquantity').val(product.quantity);

      // Set data attributes for editing
      $('#productForm').data('editing', true);
      $('#productForm').data('index', index);

      
      $('#addProductModal').modal('show');
  });

  $('#addProductModal').on('hidden.bs.modal', function () {
  
      $('#productForm')[0].reset();
      $('#productForm').removeData('editing');
      $('#productForm').removeData('index');
  });
});


//---------------------profile img-----------------------------//

function changeProfilePic() {
  debugger;
  var input = document.getElementById('picture');
  var file = input.files[0];
  var reader = new FileReader();
  reader.onload = function (event) {
    var imgSrc = event.target.result;
    var imgSrc2 = event.target.result;
    document.getElementById('profile-pic').src = imgSrc;
    document.getElementById('profile-pic2').src = imgSrc2;
  };

  // Initiating the file reading process
  reader.readAsDataURL(file);
}

//----------------------Profile data----------------------------//




function saveData() {
  var Name = document.getElementById('fullName').value;
  var email = document.getElementById('email').value;
  var phone = document.getElementById('phone').value;
  var linkedin = document.getElementById('linkedin').value;
  var street = document.getElementById('street').value;
  var city = document.getElementById('city').value;
  var state = document.getElementById('state').value;
  var zip = document.getElementById('zip').value;


  if (Name.trim() !== '' && email.trim() !== '' && phone.trim() !== '' && linkedin.trim() !== '' && street.trim() !== '' && city.trim() !== '' && state.trim() !== '' && zip.trim() !== '') {


    var data = {
      fullname: Name,
      Email: email,
      phone: phone,
      Linkedin: linkedin,
      Street: street,
      City: city,
      State: state,
      Zip: zip,
    };


    localStorage.setItem('ProfileData', JSON.stringify(data));
    alert('Data saved successfully!');

    // Check for existing form data in local storage
    var storedData = localStorage.getItem("formData");
    var formData = storedData ? JSON.parse(storedData) : [];

    formData.push(data);


    localStorage.setItem("formData", JSON.stringify(formData));

  } else {
    alert('Please fill out all fields.');
  }

  window.location.href = "index.html";
}

// Populate input fields with data from local storage when page loads
window.onload = function () {
  var storedProfileData = localStorage.getItem('ProfileData');
  if (storedProfileData) {
    var profileData = JSON.parse(storedProfileData);
    console.log(profileData);
    document.getElementById('fullName').value = profileData.fullname;
    document.getElementById('email').value = profileData.Email;
    document.getElementById('phone').value = profileData.phone;
    document.getElementById('linkedin').value = profileData.Linkedin;
    document.getElementById('street').value = profileData.Street;
    document.getElementById('city').value = profileData.City;
    document.getElementById('state').value = profileData.State;
    document.getElementById('zip').value = profileData.Zip;
  }
};


//-------------------------------------notification--------------------------------//



//---------------------------------chart navigation-------------------//



function toggleSidebar() {
  var sidebar = document.getElementById("sidebarMenu");
  sidebar.classList.toggle("show");
}

function closenav() {
  var sidebar = document.getElementById("sidebarMenu");
  sidebar.classList.toggle("show");
}


