// var formcondition = document.getElementById("taskForm")
// if (formcondition == false) {
//     $('#taskForm').modal('open');
// }

// $(document).ready(function () {
//     $('#taskForm').modal({ backdrop: 'static', keyboard: false });



//     $(document).click(function () {
//       $('#closeBtn').click('hide');
//     });
// });

// function savetask() {
//   var Task = document.getElementById('task').value;
//   var Date = document.getElementById('date').value;
//   var Time = document.getElementById('time').value;


//  var taskdata = {
//       taskname: Task,
//       date: Date,
//       time: Time,
//     };

//     localStorage.setItem('Taskdata', JSON.stringify(taskdata));
// }

// $(document).ready(function () {
//     loadCards();

//     $('#taskForm').submit(function (event) {
//         event.preventDefault();
//         let title = $('#task').val();
//         let date = $('#date').val();
//         let time = $('#time').val();
//         addCard(title, date, time);
//         $('#taskmodal').modal('hide');
//     });

//     function addCard(title, date, time) {
//         let cards = JSON.parse(localStorage.getItem('Taskdata')) || [];
//         let card = {
//             tasktitle: title,
//             taskdate: date,
//             tasktime: time,
//         };
//         cards.push(card);
//         localStorage.setItem('Taskdata', JSON.stringify(cards));
//         displayCards();
//     }

//     function displayCards() {
//         let cards = JSON.parse(localStorage.getItem('cards')) || [];
//         let cardContainer = $('#cardContainer');
//         cardContainer.empty();
//         cards.forEach(function (card, index) {
//             let cardHtml = `<div class="card">
//                             <div class="card-body d-flex">
//                                 <h5 class="card-title ms-4">${card.title}</h5>
//                                 <p class="card-datecms-4">Date: ${card.date}</p>
//                                 <p class ="card-time ms-4">Time:${card.time}</p>
//                                 <button class="btn btn-primary" onclick="editCard(${index})">Edit</button>
//                                 <button class="btn btn-danger" onclick="deleteCard(${index})">Delete</button>
//                             </div>
//                         </div>`;
//             cardContainer.append(cardHtml);
//         });
//     }

//     window.deleteCard = function (index) {
//         let cards = JSON.parse(localStorage.getItem('cards')) || [];
//         cards.splice(index, 1);
//         localStorage.setItem('cards', JSON.stringify(cards));
//         displayCards();


//     }
//     function loadCards() {
//         if (localStorage.getItem('cards')) {
//             displayCards();
//         }
//     }

// });



// $(document).ready(function() {
//     loadCards();

//     // -----------Add card form submit event--------------------------//
//     $('#addCardForm').submit(function(event) {
//         event.preventDefault();
//         let title = $('#inputTitle').val();
//         let dateTime = $('#inputDateTime').val();
//         addCard(title, dateTime);
//         $('#addCardModal').modal('hide');
//     });

//     //------------ Function to add a new card--------------------------//
//     function addCard(title, dateTime) {
//         let cards = JSON.parse(localStorage.getItem('cards')) ;
//         let card = {
//             title: title,
//             dateTime: dateTime
//         };
//         cards.push(card);
//         localStorage.setItem('cards', JSON.stringify(cards));
//         displayCards();
//     }

//     // -------------------------Function to display cards-------------------------//
//     function displayCards() {
//         let cards = JSON.parse(localStorage.getItem('cards')) ;
//         let cardContainer = $('#cardContainer');
//         cardContainer.empty();
//         cards.forEach(function(card, index) {
//             let cardHtml = `<div class="card">
//                                 <div class="card-body d-flex">
//                                     <h5 class="card-title mx-5 bg">${card.title}</h5>
//                                     <p class="card-text mx-4">Date and Time: ${card.dateTime}</p>
//                                     <button class="btn btn-primary me-4 " onclick="editCard(${index});">Edit</button>
//                                     <button class="btn btn-danger" onclick="deleteCard(${index})">Delete</button>
//                                 </div>
//                             </div>`;
//             cardContainer.append(cardHtml);
//         });
//     }

//     //-------------------------------- Function to edit a card--------------------------//
//     window.editCard = function(index) {
//         let cards = JSON.parse(localStorage.getItem('cards')) || [];
//         let card = cards[index];
//         $('#inputTitle').val(card.title);
//         $('#inputDateTime').val(card.dateTime);
//         cards.splice(index, 1);
//         localStorage.setItem('cards', JSON.stringify(cards));
//         displayCards();
//     };

//     // ------------------------Function to delete a card---------------------------------//
//     window.deleteCard = function(index) {
//         let cards = JSON.parse(localStorage.getItem('cards')) || [];
//         cards.splice(index, 1);
//         localStorage.setItem('cards', JSON.stringify(cards));
//         displayCards();
//     };

//     function loadCards() {
//         if (localStorage.getItem('cards')) {
//             displayCards();
//         }
//     }
    

    
// });








  // Display cards when the page loads
  window.onload = function() {
    displayCards();
  };

  // Function to open modal for adding or editing card
  window.editCard = function(index) {
    if (index === undefined) {
      // If index is undefined, it means we're adding a new card
      $('#editTitle').val('');
      $('#editDateTime').val('');
      $('#editIndex').val('');
    } else {
      // If index is defined, it means we're editing an existing card
      let cards = JSON.parse(localStorage.getItem('cards')) || [];
      let card = cards[index];
      $('#editTitle').val(card.title);
      $('#editDateTime').val(card.dateTime);
      $('#editIndex').val(index);
    }
    $('#addCardModal').modal('show');
  };

  // Function to save card (both for adding and editing)
  function saveCard() {
    let cards = JSON.parse(localStorage.getItem('cards')) || [];
    let index = $('#editIndex').val();
    let editedCard = {
      title: $('#editTitle').val(),
      dateTime: $('#editDateTime').val()
    };
    if (index === '') {

      cards.push(editedCard);
    } else {
  
      cards[index] = editedCard;
    }
    localStorage.setItem('cards', JSON.stringify(cards));
    displayCards(); 
    $('#addCardModal').modal('hide'); 
  }

  // Function to display cards in a specific id
  function displayCards() {
    let cards = JSON.parse(localStorage.getItem('cards')) || [];
    let cardDisplay = document.getElementById('cardContainer');
    cardDisplay.innerHTML = ''; 
    cards.forEach(function(card, index) {
      let cardHTML = `<div class="card mb-3">
                        <div class="card-body d-flex justify-content-between">
                          <div>
                            <h5 class="card-title">${card.title}</h5>
                            <p class="card-text">${card.dateTime} required</p>
                          </div>
                          <div>
                            <button type="button" class="btn btn-danger me-3" onclick="deleteCard(${index})">Delete</button>
                            <button type="button" class="btn btn-primary" onclick="editCard(${index})">Edit</button>
                          </div>
                        </div>
                      </div>`;
      cardDisplay.innerHTML += cardHTML;
    });
  }

  // Function to delete card
  function deleteCard(index) {
    let cards = JSON.parse(localStorage.getItem('cards')) || [];
    cards.splice(index, 1);
    localStorage.setItem('cards', JSON.stringify(cards));
    displayCards(); 
  }

  function checkTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const now = new Date().getTime();
    tasks.forEach(task => {
      const taskTime = new Date(task.dateTime).getTime();
      if (taskTime - now <= 600000 && taskTime - now > 0) { // Within 10 minutes
        displayNotification(task);
      }
    });
  }